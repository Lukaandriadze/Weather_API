from flask import Flask, render_template, request
import requests
app = Flask(__name__)
API_KEY = 'cfd8b575beb2ebb4fdd5aca3a1e9a8cc'
BASE_URL = 'https://api.openweathermap.org/data/2.5/weather'
@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None
    if request.method == 'POST':
        city = request.form.get('city')
        if city:
            response = requests.get(BASE_URL, params={'q': city, 'appid': API_KEY, 'units': 'metric'})
            if response.status_code == 200:
                weather_data = response.json()
            else:
                weather_data = {'error': 'სამწუხაროდ ინფორმაცია არ არის.'}
    return render_template('index.html', weather=weather_data)
if __name__ == '__main__':
    app.run(debug=True)
